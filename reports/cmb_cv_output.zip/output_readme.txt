This archive contains the cross-validation output under various conditions for each of the 3 datasets we studied.

The column headings in each file may include the following terms:
  p, dr1, kpca s, kpls s, k, kfd s, svm s

Here:

  p	== p-value threshold used for the T-test
dr1	== dimensionality reduction (number of latent variables in either pca/kpca or pls/kpls); this is "K" in E. Brevdo's report.
kpca s	== sigma value used in the RBF kernel for KPCA
kpls s	== sigma value used in the RBF kernel for KPLS
  k	== "k" in the k-nearest neighbors algorithm used as baseline classification
kfd s	== sigma value used in the RBF kernel for KFD
svm s 	== sigma value used in the RBF kernel for KSVM

The last column is always the error as calculated when classifying during cross-validation.




The file structure is as follows:

- alon_et_al/*_out.txt
	Leave-4-out cross-validation output on the Alon et al. dataset

- output/all_*_out.txt
	Golub et al. dataset: train on first 38, test on last 34

- output/*_out.txt (rest)
	Golub et al. dataset: leave-1-out cross-validation on first 38 samples

- wei_et_al/*_out.txt
	Leave-1-out cross-validation output on the Wei et al. dataset
