% Reproducibility.  Remove to test stability.
randn('state', 10); rand('state', 10);
randn('seed', 10); rand('seed', 10);

lambda = 1e5;
tu = linspace(0,10,1024);
tn = 11/300*[0:300-1]+11/310*rand(1,300);

nv = 32;
nw = 16;

opt = struct('type', 'bump', ... % bump
             'ticklabels', {{'1', '2', '5', '20', '50'}});

feq1 = @(t) (1+0.5*cos(t)).*cos(4*pi*t);
feq2 = @(t) 2*exp(-0.1*t).*cos(2*pi*(3*t + 0.25*sin(1.4*t)));
feq3 = @(t) (1+0.5*cos(2.5*t)).*cos(2*pi*(5*t+2*t.^(1.3)));
feq = @(t) feq1(t) + feq2(t) + feq3(t);
fu = feq(tu);
fus = [feq1(tu)' feq2(tu)' feq3(tu)'];

fn = feq(tn);

% Spline
fn_resamp = interp1(tn,fn,tu,'spline');

norm(fn_resamp-fu,2)
norm(fn_resamp-fu,Inf)

% Step 0 - estimate gamma
[Wf, a] = cwt_fw(fn_resamp, opt.type, nv, 1, opt);
opt.gamma = est_riskshrink_thresh(Wf, nv);
opt.gamma
clear Wf;

% Step 1 - calc synsq
[Tf,w,Wf,a,wf] = synsq_cwt_fw(tu, fn_resamp, nv, opt);

% Step 2 - extact 3 signals
[Cs, Es] = curve_ext_multi(Tf, log2(w), 3, lambda, nw);
Cs = [Cs(:,1) Cs(:,3) Cs(:,2)]; % Reorder for visualization
Es = [Es(1) Es(3) Es(2)];

export_params = {'Format', 'eps2', 'Color', 'bw', 'Resolution', ...
                 600, 'FontSize', 1.2, 'FontMode', 'scaled', ...
                'Height', 8, 'Width', 6};


figure;
%hc = [];
%for j=1:5, hc(j) =subplot(5,1,j); end
hc = tight_subplot(5,1,[.015 .005], [.08 .01], [.13 .01]);

subplot(hc(1));
plot(tu, fu, 'k--', 'LineWidth', 0.5); hold on;
plot(tn, fn, 'ko', 'MarkerSize', 2);
plot(tu, fn_resamp, 'k', 'LineWidth', 1);
xlim([2 8]);
xlabel('t');
grid on; ylim([min(fu) max(fu)]);
legend({'f(t_m)', '(t'',f(t''))', 'f_s(t_m)'}, 'Location', 'SouthWest');

opt.hc = hc(2:end);
opt.draw_contours = false;
plot_ext_curves_cmp(tu, fus, Tf, w, Cs, Es, opt, nw);
ylabel('\omega');

subplot(hc(1)); ylabel('f(t)');
labeltext(' a ');

subplot(hc(2)); title('');
labeltext(' b ');
  ylim([log2(1) log2(30)]); ylabel('T_f');
  set(legend(), 'Location', 'SouthWest');

subplot(hc(3)); ylabel('f_1(t)');
labeltext(' c ');

subplot(hc(4)); ylabel('f_2(t)');
labeltext(' d ');

subplot(hc(5));
ylabel('f_3(t)'); labeltext(' e ');
set(hc, 'XTickLabel', '');


set(hc(3:end), 'YTickLabelMode', 'auto');
set(hc(end), 'XTickLabelMode', 'auto');
set(hc, 'xlim', [2 8]);


exportfig(gcf, 'ex_nonunif',export_params{:});

%close all
