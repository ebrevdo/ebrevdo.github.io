% Reproducibility.  Remove to test stability.
randn('state', 10);
randn('seed', 10);

n = 2048;
tu = linspace(0,10,n);
dt = tu(2)-tu(1);
window = hamming(n/4+1); % for STFT
window = window / norm(window, 2);

nv = 32;
view_xlim = [1.5 8.5];

opt = struct('type', 'bump');
popt = struct('bd', 0, ...
              'ticklabels', {{'1' '2' '3' '4' '5' '6' '10'}});

export_params = {'Format', 'epsc2', 'Color', 'bw', 'Resolution', ...
                 600, 'FontSize', 1.2, 'FontMode', 'scaled', ...
                 'Height', 6, 'Width', 6};

feq1 = @(t) (1+0.2*cos(t)).*cos(2*pi*(2*t+0.3*cos(t)));
feq2 = @(t) (1+0.3*cos(2*t)).*exp(-t/15).*cos(2*pi*(2.4*t+0.5*t.^(1.2)+0.3*sin(t)));
feq3 = @(t) cos(2*pi*(5.3*t-0.2*t.^(1.3)));
feq = @(t) feq1(t) + feq2(t) + feq3(t);
s2 = 5;
noise = sqrt(s2)*randn(size(tu));
fu0 = feq(tu);
fu = fu0 + noise;
snr = norm(fu0-mean(fu0))^2/norm(noise-mean(noise))^2;
fu = fu(:);

disp(sprintf('SNR is: %.3f (%.3f dB)', snr, 10*log10(snr)));

% Step 0 - gamma
[Wf, a] = cwt_fw(fu, opt.type, nv, 1, opt);
opt.gamma = est_riskshrink_thresh(Wf, nv);
clear Wf;

% Step 1 - calc synsq
[Tf,w,Wf,a,wf] = synsq_cwt_fw(tu, fu, nv, opt);

% Step 2 - calc SPWVD
nf = round(nv*log2(length(tu)));
[tmp, WVD_t, WVD_f] = tfrspwv(fu);
[WVD_fn, RWVD_fn] = tfrrspwv(fu); % 2x-freq by t
WVD_fn = WVD_fn(2:n,:);
RWVD_fn = RWVD_fn(2:n,:);
WVD_f = 1/dt * WVD_f(2:n);

% Step 3 - calc reassigned spectrogram
[tmp, SP_t, SP_f] = tfrsp(fu, 1:n, n, window);
[SP_fn, RSP_fn] = tfrrsp(fu);
SP_fn = SP_fn(2:n/2+1,:);
RSP_fn = RSP_fn(2:n/2+1,:);
SP_f = 1/dt * SP_f(2:n/2+1);
SP_f(end) = -SP_f(end);

figure;
hc = tight_subplot(3,1,[.01 .005], [.08 .01], [.14 .01]);

subplot(hc(1));
tplot(Tf, tu, w, popt);
ylim([log2(1) log2(8)]);
xlim(view_xlim);
ylabel('Synchrosqueezing');
set(hc(1), 'XTickLabel', '');
labeltext(' a ');

subplot(hc(2));
tplot(RSP_fn, tu, SP_f, popt);
ylim([0 8]);
xlim(view_xlim);
ylabel('RSP');
set(hc(2), 'XTickLabel', '');
labeltext(' b ');

subplot(hc(3));
tplot(RWVD_fn, tu, WVD_f, popt);
ylim([0 8]);
xlim(view_xlim);
ylabel('RWVD');
labeltext(' c ');

exportfig(gcf, 'ex_synsq_vs_tfr',export_params{:});

close(gcf)
