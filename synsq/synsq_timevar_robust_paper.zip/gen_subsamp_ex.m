% Reproducibility.  Remove to test stability.
randn('state', 10);
randn('seed', 10);

nv = 32;

opt = struct('type', 'bump');

%% Completely synthetic
%t = linspace(0,10,1000);
%f = cos(2*pi*t)+cos(2*pi*2*t)+cos(2*pi*4*t)+cos(2*pi*8*t)+cos(2*pi*12*t) ...
%    + .1*cumsum(randn(size(t)));
%samp = [1:8:333 334:4:666 667:1000];


%% S&P 500 log returns
% data = importdata('sp500.csv');
% t0 = data.data(2:end,1) / 365;
% f0 = data.data(2:end,3);
% t = min(t0):7/365:max(t0);
% f = interp1(t0,f0,t,'spline');
% samp = [1:8:1092 1093:4:2085 2086:length(t)];

%data = importdata('~/research/datasets/neven/paleoclimate/rad.65N.90.data1.txt');
data = importdata('~/research/datasets/neven/paleoclimate/PHbenthic.data.txt');
t = data(:,1)/1e3; % kyr
f = -data(:,2);
samp = [1:20:500 510:10:1000 1005:5:1500 1502:2:2000 2001:1:2501];

ts = t(samp);
fs = f(samp);

fu = interp1(ts,fs,t,'spline');

% Step 1 - calc synsq of both original and fitted signals
[Tf,w] = synsq_cwt_fw(t, f, nv, opt);

[Tfu,w] = synsq_cwt_fw(t, fu, nv, opt);

export_params = {'Format', 'epsc2', 'Color', 'bw', 'Resolution', ...
                 600, 'FontSize', 1.2, 'FontMode', 'scaled', ...
                 'Height', 3, 'Width', 10};

figure;
%hc = tight_subplot(2,2,[.01 .01], [.12 .01], [.13 .1]);
hc = tight_subplot(1,2,[.01 .01], [.18 .01], [.13 .01]);

subplot(hc(1));
% plot(t, fu, 'k', ts, fs, 'r.');
% grid on;
% xlim([min(t) max(t)]);
% ylim([min(f) max(f)]);
% ylabel('f(t)');

tplot(Tfu,t,1./w, ...
      struct('ticklabels', {{'10', '20', '40', '60', '100', ...
                    '200', '400'}}));
ylim([log2(5) log2(450)]);
grid on;
xlabel('t (Myr)');
ylabel('\tau = 2 \pi \omega^{-1} (kyr)');
set(gca, 'XTick', 1000*[-2 -1.5 -1 -.5 0]);
set(gca, 'XTickLabel', arrayfun(@(x){num2str(x/1000)}, get(gca, 'XTick')));
labeltext(' a ');

subplot(hc(2));
tplot(Tf-Tfu,t,1./w, ...
      struct('ticklabels', {{'10', '20', '40', '60', '100', ...
                    '200', '400'}}));
ylim([log2(5) log2(450)]);
caxis(caxis(hc(1))); % Scale colors appropriately
set(gca, 'YTickLabel', '');
xlabel('t (Myr)');
grid on;
set(gca, 'XTick', 1000*[-2 -1.5 -1 -.5 0]);
set(gca, 'XTickLabel', arrayfun(@(x){num2str(x/1000)}, get(gca, 'XTick')));
labeltext(' b ');
%set(gca, 'YAxisLocation', 'right');
%ylabel('\tau = 2 \pi \omega^{-1} (kyr)');

exportfig(gcf, 'ex_subsamp',export_params{:});
