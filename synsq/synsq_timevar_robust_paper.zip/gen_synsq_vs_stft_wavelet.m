% Reproducibility.  Remove to test stability.
randn('state', 10);
randn('seed', 10);

n = 2048;
tu = linspace(0,10,n);
dt = tu(2)-tu(1);
window = hamming(n/4+1); % for STFT
window = window / norm(window, 2);

nv = 32;
view_xlim = [1.5 8.5];

opt = struct('type', 'bump');


export_params = {'Format', 'eps2', 'Color', 'bw', 'Resolution', ...
                 600, 'FontSize', 1.2, 'FontMode', 'scaled', ...
                 'Height', 6, 'Width', 8};


feq1 = @(t) (1+0.2*cos(t)).*cos(2*pi*(2*t+0.3*cos(t)));
feq2 = @(t) (1+0.3*cos(2*t)).*exp(-t/15).*cos(2*pi*(2.4*t+0.5*t.^(1.2)+0.3*sin(t)));
feq3 = @(t) cos(2*pi*(5.3*t-0.2*t.^(1.3)));
feq = @(t) feq1(t) + feq2(t) + feq3(t);
s2 = 2.4;
noise = sqrt(s2)*randn(size(tu));
fu0 = feq(tu);
fu = fu0 + noise;
snr = norm(fu0-mean(fu0))^2/norm(noise-mean(noise))^2;



disp(sprintf('SNR is: %.3f (%.3f dB)', snr, 10*log10(snr)));

% Step 1 - calc synsq, wavelet, and STFT

[Wf0, a] = cwt_fw(fu, opt.type, nv, dt, opt);

% Estimate noise level and filter signal for all steps following this.
thresh = est_riskshrink_thresh(Wf0, nv);
disp(sprintf('Estimated noise threshold gamma at: %.3f', thresh));
Wf0(find(abs(Wf0)<thresh)) = 0.0; % Hard thresholding.
fur = cwt_iw(Wf0, opt.type, opt);

[Tf,w,Wf,a,wf] = synsq_cwt_fw(tu, fur, nv, opt);

[Sf0,Stau0,Sw0] = tfrstft(fu(:), 1:n, n, window);
Stau = Stau0*dt;
% Cut out positive frequencies
Sf = Sf0(2:n/2+1,:);
Sw = 1/dt * Sw0(2:n/2+1);
Sw(end) = -Sw(end); % Negative high freq == positive high freq

figure;
hc = tight_subplot(2,2,[.02 .06], [.08 .01], [.14 .01]);

subplot(hc(1));
plot(tu, fu0, 'LineWidth', 3);
hold on;
plot(tu, fu, 'g--');
axis tight;
xlim(view_xlim); % To match STFT plot axes
set(hc(1), 'XTickLabel', '');
ylabel('s(t)');
labeltext(' a ');

subplot(hc(2));
tplot(Sf, Stau, Sw, ...
      struct('bd', 0, ...
             'ticklabels', {{'1' '2' '3' '4' '5' '6' '10'}}));
%ylim([log2(1) log2(8)]);
ylim([0 8]);
ylabel('\omega');
xlim(view_xlim);
labeltext(' b ');
set(hc(2), 'XTickLabel', '');

subplot(hc(3));
tplot(flipud(Wf),tu,a(end:-1:1), struct('style','scale', ...
                      'ticklabels', {{'0.1', '0.2', '0.3', '0.4', ...
                    '0.6', '0.8'}}));
ylim([log2(.0625) log2(1)]);
ylabel('a');
%set(hc(2), 'YAxisLocation', 'right');
xlim(view_xlim);
labeltext(' c ');
set(hc(3), 'XTick', [2:2:8]);
xlim(view_xlim);
xlabel('t');

subplot(hc(4));
tplot(Tf,tu,w, ...
      struct('ticklabels', {{'.25' '.5' '1' '2' '3' '4' '5' '6' '10'}}));
ylim([log2(1) log2(8)]);
ylabel('\omega');
xlim(view_xlim);
%set(hc(4), 'YAxisLocation', 'right');
set(hc(4), 'XTick', [2:2:8]);
xlabel('t');
labeltext(' d ');

%set(gcf, 'renderer', 'zbuffer');
exportfig(gcf, 'ex_synsq_vs_stft_wavelet_analysis',export_params{:});

close(gcf)

%%%%%%%%%%%%%%%%
% Reconstruction

% Synchrosqueezing
fm = (2.4+0.5*1.2*tu.^0.2+0.3*cos(tu));
fM = (2.4+0.5*1.2*tu.^0.2+0.3*cos(tu));
Tf_f = synsq_filter_pass(Tf, w, 0.88*fm, 1.12*fM);
fu_Tf = synsq_cwt_iw(Tf_f, w, opt);

% STFT
Sf_f = synsq_filter_pass(Sf, Sw, 0.88*fm, 1.12*fM);
% Re-pad Sf_f to proper frequencies
Sf_f = [Sf0(1,:); Sf_f; conj(Sf_f(end:-1:1,:))];
%fu_Sf = stft_iw(Sf_f, stft_opt);
fu_Sf = tfristft(Sf_f, 1:n, window);

% Wavelet
am = 0.2 * ones(size(tu));
aM = 0.3 * ones(size(tu));
Wf_f = synsq_filter_pass(Wf, a, am, aM);
fu_Wf = cwt_iw(Wf_f, opt.type, opt);

figure;

hd = tight_subplot(3,1,[.1 .005], [.08 .01], [.14 .01]);

subplot(hd(1));
plot(tu, feq2(tu), tu, fu_Tf, 'r.');
ylim([-1, 1]);
set(hd(1), 'XTickLabel', '');
ylabel('Synchrosqueezing');
xlim(view_xlim);
labeltext(' a ');

subplot(hd(2));
plot(tu, feq2(tu), tu, fu_Sf, 'r.');
ylim([-1, 1]);
set(hd(2), 'XTickLabel', '');
ylabel('STFT');
xlim(view_xlim);
labeltext(' b ');

subplot(hd(3));
plot(tu, feq2(tu), tu, fu_Wf, 'r.');
ylim([-1, 1]);
ylabel('CWT');
xlim(view_xlim);
labeltext(' c ');
xlabel('t');

exportfig(gcf, 'ex_synsq_vs_stft_wavelet_synthesis',export_params{:});

close(gcf)
