Code used to generate figures for the article:

G. Thakur, E. Brevdo, N.S. Fu\v{c}kar, and H-T. Wu. The Synchrosqueezing
algorithm for time-varying spectral analysis: robustness properties and new
paleoclimate applications. 2012.

Authors: Eugene Brevdo (http://www.math.princeton.edu/~ebrevdo/)

If you use this code in your research, please include the citations to
this paper and code.

Requirements
--------------

This code uses the Synchrosqueezing toolbox v1.1, which can
be found on the author's website:
  http://web.math.princeton.edu/~ebrevdo/synsq/

Some scripts (those that use the STFT) also need the the time-frequency analysis
matlab toolbox, which can be found here:
  http://tftb.nongnu.org/

Installation
-------------

0. You need to download the Synchrosqueezing and TF toolboxes from
   the Requirements section.  Follow their instructions to install.

1. Extract the zip in an empty directory.

2. Add the new directory to your path; e.g., run:
    addpath synsq_timevar_robust_paper;
    addpath synsq_timevar_robust_paper/paleoclimate;
    addpath synsq_timevar_robust_paper/util;

3. Go into the new directory and run the figure generation
   scripts one at a time.  These will create .eps figures
   in this directory.


Descriptions of Matlab Scripts
-------------------------------

gen_nonunif_fig: Generates an example with discontinuities and other
 interesting properties.

gen_paleo_figs: Generates most of the figures used in the paleoclimate section

gen_simple_ex_fig: Generates the first, simple, example figure

gen_subsamp_ex: Generates an example in which a nonuniformly subsampled
 signal is processed.

gen_synsq_vs_stft_wavelet: Compares Synchrosqueezing to the STFT.

gen_synsq_vs_tfr: Compares Synchrosqueezing synthesis to state-of-the-art
 transforms: the reassigned WVD and the reassigned STFT.

gen_wavelet_cmp: Compares Synchrosqueezing to the Wavelet transform.
