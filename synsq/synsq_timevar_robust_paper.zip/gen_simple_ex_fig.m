t = linspace(0,10,1024);
nv = 32;
f0 = (1+0.6*cos(2*t)).*cos(4*pi*t+1.2*t.^2);
sigma = 0.5;
f = f0 + sigma*randn(size(t));
opt = struct('type', 'bump');

[Wf, a] = cwt_fw(f0, opt.type, nv, t(2)-t(1), opt);
opt.gamma = est_riskshrink_thresh(Wf, nv);
clear Wf;

[Tf,w,Wf,a,wf] = synsq_cwt_fw(t, f, nv, opt);

figure;
ha=tight_subplot(2,2,[.01 .09], [.14 .01], [.12 .018]);

export_params = {'Format', 'epsc2', 'Color', 'bw', 'Resolution', ...
                 600, 'FontSize', 1.3, 'FontMode', 'scaled', ...
                'Height', 4, 'Width', 6};

subplot(ha(1));

plot(t, f0, 'LineWidth', 1.25);
hold on;
plot(t, f, 'r--', 'LineWidth', 0.5);
set(gca, 'XTick', []);
ylabel('f(t)');
labeltext(' a ');
legend('f(t)', 'f(t)+e(t)');

subplot(ha(2));
%figure;
%{'.05','.1','.5','1','5'}
tplot(flipud(Wf),t,a(end:-1:1),struct('style','scale', 'ticklabels', {{'.05','.1','.5','1','5'}},'bd',0)); %colorbar;
%xlabel('t');
ylabel('a');
set(gca, 'XTick', []);
%exportfig(gcf, 'ex_simple_Wf',export_params{:});
labeltext(' b ');

subplot(ha(3));
%figure;
tplot(Tf,t,w,struct('ticklabels',{{'.5','1','2','5','10'}},'bd',0));
xlabel('t');
ylabel('\omega');
ylim([log2(.5) log2(25)]);
%exportfig(gcf, 'ex_simple_Tf',export_params{:});
labeltext(' d ');

subplot(ha(4));
tplot(flipud(wf),t,a(end:-1:1),struct('style','scale','ticklabels', {{'.05','.1','.5','1','5'}},'bd',0));
caxis([0 4]); %colorbar;
xlabel('t');
ylabel('a');
labeltext(' c ');

exportfig(gcf, 'ex_new',export_params{:});
close all
