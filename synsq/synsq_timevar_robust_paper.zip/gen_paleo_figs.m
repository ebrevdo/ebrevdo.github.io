fn1 = 'paleoclimate/rad.65N.90.data1.txt';
opt1 = struct('dt', 1000, 'trev', 0, 'delim', ' ');

fn2 = 'paleoclimate/DSDP607_clean.data.txt';
opt2 = struct('dt', 1000, 'trev', 1, 'delim', ' ');

fn3 = 'paleoclimate/lisiecki2005_clean.data.txt';
opt3 = struct('dt', 1000, 'trev', 1, 'delim', ' ');

fn4 = 'paleoclimate/PHbenthic.data.txt';
opt4 = struct('dt', 1000, 'trev', 0, 'delim', ' ');

tauticklabels = {{'5', '10', '20', '40', '60', ... % 80, 120
                  '100', '200', '400', '800'}};

flim = [5 800]; % Periodicity limits (in kyr)

gopt = struct('bd', 1, 'ticklabels', tauticklabels, ...
              'flim', flim, 'type', 'bump', 'mu', 2*pi, ... % wavelet type
              'filter', 0, ... % do not filter when calc. spectrum
              'gamma', 1.5*10^-2);

export = 1;

% 'Color', 'cmyk'
export_params = {'Format', 'epsc2', 'Color', 'bw', 'Resolution', ...
                 600, 'FontSize', 1.5, 'FontMode', 'scaled', ...
                 'Height', 10, 'Width', 8};


% Basic parameters - interpolation type and synsq type
opt1.intmethod = 'spline'; % other options include 'cubic', see help interp1
opt1.trord = 1; % trend polynomial order; removed: 0 = mean, 1 = linear, 2 = quadratic...
opt1.type = gopt.type; % Wavelet type
opt1.mu=gopt.mu;
opt1.gamma=gopt.gamma;
opt2.intmethod = 'spline';
opt2.trord = 1;
opt2.type = gopt.type;
opt2.mu=gopt.mu;
opt2.gamma=gopt.gamma;
opt3.intmethod = 'spline';
opt3.trord = 1;
opt3.type = gopt.type;
opt3.mu=gopt.mu;
opt3.gamma=gopt.gamma;
opt4.intmethod = 'spline';
opt4.trord = 1;
opt4.type = gopt.type;
opt4.mu=gopt.mu;
opt4.gamma=gopt.gamma;

% Basic parameters - number of voices
opt1.nv = 32;
opt2.nv = 32;
opt3.nv = 32;
opt4.nv = 32;

% Basic parameters - filtering frequencies
filters = {[1/25e3 1/17e3],...  % precession (18-24kyr)
           [1/55e3 1/40e3],...  % obliquity (40-55kyr)
           [1/130e3 1/90e3]};  % eccentricity (90-130kyr)
nfilt = length(filters);

%filtlabels = {'Precession', 'Obliquity', 'Eccentricity'};
%filtspecs = {':+k', '--xk', '-k'}; % line types
filtspecs = {':k', '--k', '-k'}; % line types
fspcg = {'LineWidth', 2, 'MarkerSize', 1};
labels = {' a - Insolation Index ', ' b - DSDP607 ', ...
          ' c - LR05 Stack ', ' d - H07 Stack '};
labels2 = {' e - Insolation Index ', ' f - DSDP607 ', ...
          ' g - LR05 Stack ', ' h - H07 Stack '};
taulabels = { ' c - Precession Band ', ' d - Obliquity Band ', ...
              ' e - Eccentricity Band ' };

% Run analyses
[t1,x1,tint1,xintrt1,p1,Txint1,fsint1,Wxint1,asint1] = interp_synsq_file(fn1, opt1);
[t2,x2,tint2,xintrt2,p2,Txint2,fsint2,Wxint2,asint2] = interp_synsq_file(fn2, opt2);
[t3,x3,tint3,xintrt3,p3,Txint3,fsint3,Wxint3,asint3] = interp_synsq_file(fn3, opt3);
[t4,x4,tint4,xintrt4,p4,Txint4,fsint4,Wxint4,asint4] = interp_synsq_file(fn4, opt4);

xfs = cell(4, 1);
xfs{1} = zeros(length(tint1), nfilt);
xfs{2} = zeros(length(tint2), nfilt);
xfs{3} = zeros(length(tint3), nfilt);
xfs{4} = zeros(length(tint4), nfilt);
% Filter around center
for nfi=1:nfilt
  Txintf1 = synsq_filter_pass(Txint1, fsint1, filters{nfi}(1), filters{nfi}(2));
  xfs{1}(:,nfi) = synsq_cwt_iw(Txintf1, fsint1, opt1);
  clear Txintf1;
  Txintf2 = synsq_filter_pass(Txint2, fsint2, filters{nfi}(1), filters{nfi}(2));
  xfs{2}(:,nfi) = synsq_cwt_iw(Txintf2, fsint2, opt2);
  clear Txintf2;
  Txintf3 = synsq_filter_pass(Txint3, fsint3, filters{nfi}(1), filters{nfi}(2));
  xfs{3}(:,nfi) = synsq_cwt_iw(Txintf3, fsint3, opt3);
  clear Txintf3;
  Txintf4 = synsq_filter_pass(Txint4, fsint4, filters{nfi}(1), filters{nfi}(2));
  xfs{4}(:,nfi) = synsq_cwt_iw(Txintf4, fsint4, opt4);
  clear Txintf4;
end

% Calculate DFT
[Fx1, wFs1] = dft_fw(tint1, xintrt1, opt1); tauFs1 = 1./wFs1;
[Fx2, wFs2] = dft_fw(tint2, xintrt2, opt2); tauFs2 = 1./wFs2;
[Fx3, wFs3] = dft_fw(tint3, xintrt3, opt3); tauFs3 = 1./wFs3;
[Fx4, wFs4] = dft_fw(tint4, xintrt4, opt4); tauFs4 = 1./wFs4;
Fx1 = 2*pi*Fx1; % Get back original magnitudes
Fx2 = 2*pi*Fx2; % Get back original magnitudes
Fx3 = 2*pi*Fx3; % Get back original magnitudes
Fx4 = 2*pi*Fx4; % Get back original magnitudes

% Calculate time-average means of absolute values
Css1 = synsq_adm(opt1.type, opt1);
Css2 = synsq_adm(opt2.type, opt2);
Css3 = synsq_adm(opt3.type, opt3);
Css4 = synsq_adm(opt4.type, opt4);
qs = .5; %[.31 .5 .69];
qTxint1 = synsq_filtered_time_quantile(abs(Txint1), tint1, fsint1, gopt, qs);
qTxint2 = synsq_filtered_time_quantile(abs(Txint2), tint2, fsint2, gopt, qs);
qTxint3 = synsq_filtered_time_quantile(abs(Txint3), tint3, fsint3, gopt, qs);
qTxint4 = synsq_filtered_time_quantile(abs(Txint4), tint4, fsint4, gopt, qs);
qTxint1 = 1/Css1*qTxint1;
qTxint2 = 1/Css2*qTxint2;
qTxint3 = 1/Css3*qTxint3;
qTxint4 = 1/Css4*qTxint3;

%% Wavelet display
figure;

ha=tight_subplot(4,2,[.02 .1], [.08 .01], [.13 .02]);

gopt.style = 'scale'; % for wavelet

subplot(ha(1));
tplot(flipud(Wxint1), tint1 / 1e3, 1e-3 * asint1(end:-1:1), gopt);
%colorbar;
ylabel('a (kyr)');
set(gca, 'XTickLabel', '');
%ylim([log2(10) log2(600)]);
xlim([-2.5e3 0]);
labeltext(labels{1});
set(gca, 'YMinorGrid', 'off');
grid on;
%colorbar;

subplot(ha(3));
tplot(flipud(Wxint2), tint2 / 1e3, 1e-3 * asint2(end:-1:1), gopt);
%colorbar;
ylabel('a (kyr)');
set(gca, 'XTickLabel', '');
%ylim([log2(10) log2(600)]);
xlim([-2.5e3 0]);
labeltext(labels{2});
set(gca, 'YMinorGrid', 'off');
grid on;
%colorbar;

subplot(ha(5));
tplot(flipud(Wxint3), tint3 / 1e3, 1e-3 * asint3(end:-1:1), gopt);
%colorbar;
ylabel('a (kyr)');
set(gca, 'XTickLabel', '');
%ylim([log2(10) log2(600)]);
xlim([-2.5e3 0]);
labeltext(labels{3});
set(gca, 'YMinorGrid', 'off');
grid on;
%colorbar;

subplot(ha(7));
tplot(flipud(Wxint4), tint4 / 1e3, 1e-3 * asint4(end:-1:1), gopt);
%colorbar;
xlabel('t (Myr)');
ylabel('a (kyr)');
%ylim([log2(10) log2(600)]);
xlim([-2.5e3 0]);
labeltext(labels{4});
set(gca, 'YMinorGrid', 'off');
grid on;
%colorbar;

% set special x tick labels (Myr)
set(gca, 'XTickLabel', arrayfun(@(x){num2str(x/1000)}, get(gca, 'XTick')));

%if (export) exportfig(gcf, 'ieee_paleo_wavelet', export_params{:}); end


%% Synsq display
%figure;

%ha=tight_subplot(4,1,[.01 .01], [.08 .01], [.13 .01]);

gopt.style = 'freq'; % for wavelet

subplot(ha(2));
tplot(Txint1, tint1 / 1e3, 1e-3 * 1./fsint1, gopt);
%colorbar;
ylabel('\tau = \omega^{-1} (kyr)');
set(gca, 'XTickLabel', '');
%ylim([log2(10) log2(600)]);
xlim([-2.5e3 0]);
labeltext(labels2{1});
set(gca, 'YMinorGrid', 'off');
grid on;
%colorbar;

subplot(ha(4));
tplot(Txint2, tint2 / 1e3, 1e-3 * 1./fsint2, gopt);
%colorbar;
ylabel('\tau = \omega^{-1} (kyr)');
set(gca, 'XTickLabel', '');
%ylim([log2(10) log2(600)]);
xlim([-2.5e3 0]);
labeltext(labels2{2});
set(gca, 'YMinorGrid', 'off');
grid on;
%colorbar;

subplot(ha(6));
tplot(Txint3, tint3 / 1e3, 1e-3 * 1./fsint3, gopt);
%colorbar;
ylabel('\tau = \omega^{-1} (kyr)');
set(gca, 'XTickLabel', '');
%ylim([log2(10) log2(600)]);
xlim([-2.5e3 0]);
labeltext(labels2{3});
set(gca, 'YMinorGrid', 'off');
grid on;
%colorbar;

subplot(ha(8));
tplot(Txint4, tint4 / 1e3, 1e-3 * 1./fsint4, gopt);
%colorbar;
xlabel('t (Myr)');
ylabel('\tau = \omega^{-1} (kyr)');
%ylim([log2(10) log2(600)]);
xlim([-2.5e3 0]);
labeltext(labels2{4});
set(gca, 'YMinorGrid', 'off');
grid on;
%colorbar;

% set special x tick labels (Myr)
set(gca, 'XTickLabel', arrayfun(@(x){num2str(x/1000)}, get(gca, 'XTick')));

if (export) exportfig(gcf, 'ieee_paleo_synsq', export_params{:}); end

%% Filtered signals
figure;

%ha=tight_subplot(3,2,[.03 .01], [.08 .01], [.05 .05]);
ha = subplot(3,2,[1 2 2]);

% extracted components + linear trend

y1 = sum(xfs{1},2).';
y4 = sum(xfs{4},2).';
y1t = atrend(tint1, y1, p1);
y4t = atrend(tint4, y4, p4);

%[ax,h1,h2] = plotyy(tint1/1e3, y1t, tint4/1e3, y4t);
h2=plot(tint4/1e3, y4t);
xlabel('');
xlim([-2.5e3 0]);
labeltext(' a - Eccentricity + Obliquity + Precession Bands ')
set(gca, 'YColor', 'k');
%set(h1, 'Color', 'k', 'LineStyle', ':', 'LineWidth', 1.5);
set(h2, 'Color', 'k', 'LineWidth', 1.5);
%set(ax(1), 'YTick', 10*[-6 -4 -2 0 2 4 6]);
set(gca, 'YTick', .1*[-8 -4 0 4 8]);
%ylim(ax(1), [-61 61]);
ylim(gca, [-1.0 1.0]);

% set special x tick labels (Myr)
xlabel('t (Myr)');
set(gca, 'XTickLabel', arrayfun(@(x){num2str(x/1000)}, get(gca, 'XTick')));


% original signal minus extracted components.
subplot(3,2,3);

%[ax,h1,h2] = plotyy(tint1/1e3, xintrt1 - y1, tint4/1e3, xintrt4 - y4);
h2 = plot(tint4/1e3, xintrt4 - y4);

set(gca, 'XTickLabel', '');
xlabel('');
%xlim(ax(1), [-2.5e3 0]);
xlim([-2.5e3 0]);
labeltext(' b - Remaining Signal ')
set(gca, 'YColor', 'k');
%set(h1, 'Color', 'k', 'LineStyle', ':', 'LineWidth', 1.5);
set(h2, 'Color', 'k', 'LineWidth', 1.5);
%set(ax(1), 'YTick', 10*[-6 -4 -2 0 2 4 6]);
set(gca, 'YTick', .1*[-8 -4 0 4 8]);
%set(gca, 'YTickLabel', '');
%ylim(ax(1), [-61 61]);
ylim([-1.0 1.0]);

% set special x tick labels (Myr)
set(gca, 'XTickLabel', arrayfun(@(x){num2str(x/1000)}, get(gca, 'XTick')));




subplot(3,2,4);

nfi = 2;
[ax,h1,h2] = plotyy(tint1/1e3, xfs{1}(:,nfi), ...
                    tint4/1e3, xfs{4}(:,nfi));
set(ax, 'XTickLabel', '');
xlabel('');
xlim(ax(1), [-2.5e3 0]);
xlim(ax(2), [-2.5e3 0]);
labeltext(taulabels{nfi});
set(ax, 'YColor', 'k');
set(h1, 'Color', 'k', 'LineStyle', ':', 'LineWidth', 1.5);
set(h2, 'Color', 'k', 'LineWidth', 1.5);
set(ax(1), 'YTick', 10*[-6 -4 -2 0 2 4 6]);
set(ax(2), 'YTick', .1*[-6 -4 -2 0 2 4 6]);
%set(ax(1), 'YTickLabel', '');
ylim(ax(1), [-61 61]);
ylim(ax(2), [-.61 .61]);

% set special x tick labels (Myr)
set(ax, 'XTickLabel', arrayfun(@(x){num2str(x/1000)}, get(gca, 'XTick')));




subplot(3,2,5);
nfi = 1;
[ax,h1,h2] = plotyy(tint1/1e3, xfs{1}(:,nfi), ...
                    tint4/1e3, xfs{4}(:,nfi));
set(ax, 'XTickLabel', '');
xlabel('');
xlim(ax(1), [-2.5e3 0]);
xlim(ax(2), [-2.5e3 0]);
labeltext(taulabels{nfi});
set(ax, 'YColor', 'k');
set(h1, 'Color', 'k', 'LineStyle', ':', 'LineWidth', 1.5);
set(h2, 'Color', 'k', 'LineWidth', 1.5);
set(ax(1), 'YTick', 10*[-6 -4 -2 0 2 4 6]);
set(ax(2), 'YTick', .1*[-6 -4 -2 0 2 4 6]);
set(ax(2), 'YTickLabel', '');
ylim(ax(1), [-61 61]);
ylim(ax(2), [-.61 .61]);

% set special x tick labels (Myr)
set(ax, 'XTickLabel', arrayfun(@(x){num2str(x/1000)}, get(gca, 'XTick')));




subplot(3,2,6);
nfi = 3;
[ax,h1,h2] = plotyy(tint1/1e3, xfs{1}(:,nfi), ...
                    tint4/1e3, xfs{4}(:,nfi));
set(ax, 'XTickLabel', '');
xlabel('');
xlim(ax(1), [-2.5e3 0]);
xlim(ax(2), [-2.5e3 0]);
labeltext(taulabels{nfi});
set(ax, 'YColor', 'k');
set(h1, 'Color', 'k', 'LineStyle', ':', 'LineWidth', 1.5);
set(h2, 'Color', 'k', 'LineWidth', 1.5);
set(ax(1), 'YTick', 10*[-6 -4 -2 0 2 4 6]);
set(ax(2), 'YTick', .1*[-6 -4 -2 0 2 4 6]);
set(ax(1), 'YTickLabel', '');
ylim(ax(1), [-61 61]);
ylim(ax(2), [-.61 .61]);

%legend('Insolation Index', 'H07 Stack', 'Location', 'SouthWest');

% set special x tick labels (Myr)
set(ax, 'XTickLabel', arrayfun(@(x){num2str(x/1000)}, get(gca, 'XTick')));

if (export)
  exportfig(gcf, 'ieee_paleo_filtered', export_params{:});
end


%% Compare DFT Fx to time-average of abs(Tf)
figure;

ha=tight_subplot(4,1,[.01 .01], [.08 .01], [.13 .02]);

subplot(ha(1));
loglog(1e-3 * tauFs1, abs(Fx1), ':k', 1e-3 * 1./fsint1, qTxint1, 'k', ...
       'LineWidth', 2);
set(gca, 'XTickLabel', '');
axis tight;
xlim(flim);
ylimold = ylim; ylim([equantile(qTxint1(find(qTxint1>0)), 3e-1), max(abs(Fx1))]);
labeltext(labels{1});
%set(gca, 'YMinorGrid', 'off');
grid on;
%colorbar;

subplot(ha(2));
loglog(1e-3 * tauFs2, abs(Fx2), ':k', 1e-3 * 1./fsint2, qTxint2, 'k', ...
       'LineWidth', 2);
set(gca, 'XTickLabel', '');
axis tight;
xlim(flim);
%ylimold = ylim; ylim([equantile(qTxint2(find(qTxint2>0)), 3e-1), max(abs(Fx2))]);
ylim([1e-3 .2]);
labeltext(labels{2});
set(gca, 'YMinorGrid', 'off');
grid on;
%colorbar;

subplot(ha(3));
loglog(1e-3 * tauFs3, abs(Fx3), ':k', 1e-3 * 1./fsint3, qTxint3, 'k', ...
       'LineWidth', 2);
%ylabel('\tau = 2 \pi \omega^{-1} (kyr)');
set(gca, 'XTickLabel', '');
axis tight;
xlim(flim);
%ylimold = ylim; ylim([equantile(qTxint3(find(qTxint3>0)), 3e-1), max(abs(Fx3))]);
ylim([1e-3 .2]);
labeltext(labels{3});
set(gca, 'YMinorGrid', 'off');
grid on;
%colorbar;

subplot(ha(4));
loglog(1e-3 * tauFs4, abs(Fx4), ':k', 1e-3 * 1./fsint4, qTxint4, 'k', ...
       'LineWidth', 2);
xlabel('\tau = 2 \pi \omega^{-1} (kyr)');
%ylabel('\tau = 2 \pi \omega^{-1} (kyr)');
axis tight;
xlim(flim);
%ylimold = ylim; ylim([equantile(qTxint4(find(qTxint4>0)), 3e-1), max(abs(Fx4))]);
ylim([1e-3 .2]);
labeltext(labels{4});
set(gca, 'YMinorGrid', 'off');
grid on;
%colorbar;

% set special x tick labels (Myr)
set(gca, 'XTick', cellfun(@(x)str2num(x), tauticklabels{1}));
set(gca, 'XTickLabel', tauticklabels{1});
%set(gca, 'XTickLabel', arrayfun(@(x){num2str(x/1000)}, get(gca, 'XTick')));

if (export) exportfig(gcf, 'ieee_paleo_spectrum', export_params{:}); end

close all