mopts = {
    struct('type', 'morlet', 's', 2*pi),
    struct('type', 'cmhat', 'mu', 1),
    struct('type', 'bump', 'mu', 5, 's', 1),
}; %    struct('type', 'hhhat', 'mu', 5)

N = length(mopts);

export_params = {'Format', 'eps2', 'Color', 'bw', 'Resolution', ...
                 600, 'FontSize', 1.5, 'FontMode', 'scaled', ...
                'Height', 8, 'Width', 8};

randn('state', 10);
randn('seed', 10);

n = 1024;
tu = linspace(0,10,n);
tn = 11/300*[0:300-1]+11/310*rand(1,300);

nv = 24;
nw = 16;

feq1 = @(t) (1+0.5*cos(t)).*cos(4*pi*t);
feq2 = @(t) 2*exp(-0.1*t).*cos(2*pi*(3*t + 0.25*sin(1.4*t)));
feq3 = @(t) (1+0.5*cos(2.5*t)).*cos(2*pi*(5*t+2*t.^(1.3)));
feq = @(t) feq1(t) + feq2(t) + feq3(t);
fu = feq(tu);
fus = [feq1(tu)' feq2(tu)' feq3(tu)'];

fn = feq(tn);

% Spline
fn_resamp = interp1(tn,fn,tu,'spline');

figure;
hc = tight_subplot(3,N,[.01 .005],[.09 .1],[.1 .05]);

for j=1:N
    opt = mopts{j};
    opt.ticklabels = {'0.01','0.05', '0.1', '0.2', '0.5','1','2', '5', ...
                      '8', '20'};
    %opt.eps = 1e-4;
    [Tf,ws,Wf,as,w] = synsq_cwt_fw(tu, fn_resamp, nv, opt);
    [psih,~,xi] = wfilth(opt.type, n, 4, opt);

    subplot(hc(j));
    plot(fftshift(xi/(2*pi)), fftshift(abs(psih)));
    grid on;
    %set(gca, 'XTickLabel', '');
    xlabel('\xi');
    set(gca, 'XAxisLocation', 'top');
    if (j>1), set(gca, 'YTickLabel', ''); 
    else ylabel('|\psi|'); end
    ylim([0 1]);
    xlim([-0.8 0.8]);
    labeltext([' ', 'a'+j-1, ' ']);

    subplot(hc(N+j));
    opt.style = 'scale';
    tplot(Wf,tu,as,opt);
    xlim([1 9]);
    ylim([log2(.01) log2(4)]);
    grid on;
    set(gca, 'XTickLabel', '');
    if (j>1), set(gca, 'YTickLabel', '');
    else ylabel('a'); end

    subplot(hc(2*N+j));
    opt.style = 'frequency';
    tplot(Tf,tu,ws,opt);
    %set(gca, 'XTickLabel', '');
    xlabel('t');
    xlim([1 9]);
    ylim([log2(.6) log2(30)]);
    if (j>1), set(gca, 'YTickLabel', ''); 
    else ylabel('\omega'); end

    %    subplot(hc(3*N+j));
    %    fr = synsq_cwt_iw(Tf, ws, opt);
    %    plot(tu,fn_resamp,'k', tu,fr,'--b');
end

exportfig(gcf, 'wavelet_cmp', export_params{:});
